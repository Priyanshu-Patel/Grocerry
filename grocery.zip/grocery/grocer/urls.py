from django.urls import path

from . import views

urlpatterns = [ 
    path('',views.index,name='index'),
    path('index',views.index,name='index'),
    path('veg',views.veg,name='veg'),
    path('admin',views.admin,name='admin'),
    path('post_new', views.post_new, name='post_new'),
    # path('register',views.register,name='register'),
    ]
   
