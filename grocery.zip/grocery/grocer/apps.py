from django.apps import AppConfig


class GrocerConfig(AppConfig):
    name = 'grocer'
