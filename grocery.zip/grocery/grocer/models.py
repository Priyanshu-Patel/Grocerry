from django.db import models

# Create your models here.
class products(models.Model):
   
    img = models.ImageField(upload_to='pic')
    name = models.CharField(max_length=100)
    price = models.IntegerField()
    qty = models.CharField(max_length=10)
    status = models.BooleanField(True)

class Post(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    contact = models.IntegerField(max_length=10)
    email = models.EmailField(max_length=255)
    address = models.CharField(max_length=500)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.IntegerField()
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
  
    
    
    
# class latestproducts(models.Model):
#     limg = models.ImageField(upload_to='pic')
#     lname = models.CharField(max_length=100)
#     lprice = models.IntegerField()
#     lqty = models.CharField(max_length=10)
#     lstatus = models.BooleanField(True)
    