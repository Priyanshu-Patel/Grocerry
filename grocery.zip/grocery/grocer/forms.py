from django import forms

from .models import Post

class PostForm(forms.ModelForm):

    class Meta:
        model = Post
        fields = ('first_name', 'last_name','contact','email','address','city','state','pincode','username','password',)