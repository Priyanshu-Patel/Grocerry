from django.shortcuts import render,redirect
from .models import products
from .views import products 
from django.contrib.auth.models import User, auth
from .forms import PostForm


# Create your views here.
def index(request):
    return render (request,'index.html')

def veg(request):
    prods = products.objects.all()
    return render (request,'veg.html',{'prods':prods})
    
    # lprods = latestproducts.objects.all()
    # return render (request,'veg.html',{'lprods':lprods})  

def admin(request):
    return render (request,'admin/')

def post_new(request):
    if request.method == "POST":
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
           
            post.save()
            return render(request,'index.html')


    else:
        form = PostForm()
        return render(request, 'post_edit.html', {'form': form})


# def register(request):
    
#     if request.method == "POST":
#         username = request.POST['username']
#         first_name = request.POST['first_name']
#         last_name = request.POST['last_name']
#         email = request.POST['email']
#         number = request.POST['number']
#         address = request.POST['address']
#         city = request.POST['city']
#         state = request.POST['state']
#         pincode = request.POST['pincode']
#         password1 = request.POST['password1']
#         password2 = request.POST['password2'] 

#         user = User.objects.create_user(username=username,first_name=first_name,last_name=last_name,email=email,number=number,address=address,city=city,state=state,pincode=pincode,password=password1  )
#         user.save(); 
#         print("user created")
#         return redirect ('/') 
       
#     else:
#         return render(request,'register.html')



#     return render (request,'register.html')

    

   
   


